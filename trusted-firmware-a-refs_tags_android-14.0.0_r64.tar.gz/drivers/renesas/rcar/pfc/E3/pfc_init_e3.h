/*
 * Copyright (c) 2018, Renesas Electronics Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef PFC_INIT_E3_H
#define PFC_INIT_E3_H

void pfc_init_e3(void);

#endif /* PFC_INIT_E3_H */
